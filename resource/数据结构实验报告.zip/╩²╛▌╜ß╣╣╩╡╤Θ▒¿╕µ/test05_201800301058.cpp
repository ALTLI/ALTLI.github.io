#include <iostream>
#include <string>
#include <cmath>
using namespace std;

struct treeNode
{
	char element;
	treeNode *leftChild;
	treeNode *rightChild;
	treeNode()
	{
		leftChild = rightChild = NULL;
	}
	treeNode(char theElement)
	{
		element = theElement;
		leftChild = rightChild = NULL;
	}
	treeNode(char theElement, treeNode *theLeftChild, treeNode *theRightChild)
	{
		element = theElement;
		leftChild = theLeftChild;
		rightChild = theRightChild;
	}
};

class arrayQueue
{
	public:
		treeNode *queue[100];
		arrayQueue()
		{
			queueFront = -1;
			elementSize = 0;
			queueBack = -1;
		}
		void push(treeNode *theTreeNode)
		{
			queueBack = (queueBack+1)%100;
			queue[queueBack] = theTreeNode;
			elementSize++;
		}
		void pop()
		{
			queueFront = (queueFront+1)%100;
			elementSize--;
		}
		treeNode* front()
		{
			return queue[(queueFront+1)%100]; 
		}
		bool empty()
		{
			return elementSize == 0;
		}
		
		
	private:
		int queueFront;
		int elementSize;
		int queueBack;
};

void preOrder(treeNode *, int &, int);
void inOrder(treeNode *, int &, int);
void postOrder(treeNode *, int &, int);
void levelOrder(treeNode *, int &, int);
treeNode* makeTree(string, string, int);

int main()
{
	string input1;
	cout << "Input1" << endl;
	cin >> input1;
	int degree1 = input1.size(); // �������Ķ��� 
	treeNode *root; // ����� 
	// ����(degree1+1)������treeNode�����飬�ڸ�����Ļ����Ͻ��������� 
	treeNode *arr1 = new treeNode[degree1+1];
	for (int i = 1; i <= degree1; i++)
	{
		arr1[i] = treeNode(input1[i-1]);
	} 
	root = &arr1[1];
	// �������forѭ���ͽ������Ϊ��һ�������� 
	for (int i = 1; i <= degree1; i++)
	{
		if (2*i <= degree1)
			arr1[i].leftChild = &arr1[2*i];
		if (2*i+1 <= degree1)
			arr1[i].rightChild = &arr1[2*i+1];
	}
	cout << "Output1" << endl;
	int judge11 = 0, judge12 = 0, judge13 = 0;
	preOrder(root, judge11, degree1);
	cout << endl;
	inOrder(root, judge12, degree1);
	cout << endl;
	postOrder(root, judge13, degree1);
	cout << endl;
	cout << degree1 << endl;
	int level = 0;
	for ( ; ; level++)
	{
		if (pow(2, level) - 1 >= degree1)
			break;	
	}
	cout << level << endl;
	cout << "Input2" << endl;
	string str21, str22;
	cin >> str21;
	cin >> str22;
	cout << "Output2" << endl;
	int degree2 = str21.size();
	root = makeTree(str21, str22, degree2);
	int judge21 = 0, judge22 = 0;
	postOrder(root, judge21, degree2);
	cout << endl;
	levelOrder(root, judge22, degree2);
	cout << endl;
	cout << "End" << endl;
	return 0;
}

void preOrder(treeNode *tn, int &judge, int degree)
{
	if (tn != NULL)
	{
		
		cout << tn->element;
		judge++;
		if (judge < degree)
			cout << ",";
		preOrder(tn->leftChild, judge, degree);
		preOrder(tn->rightChild, judge, degree);
	}
} 

void inOrder(treeNode *tn, int &judge, int degree)
{
	if (tn != NULL)
	{
		inOrder(tn->leftChild, judge, degree);
		cout << tn->element;
		judge++;
		if (judge < degree)
			cout << ",";
		inOrder(tn->rightChild, judge, degree);
	}
}

void postOrder(treeNode *tn, int &judge, int degree)
{
	if (tn != NULL)
	{
		
		postOrder(tn->leftChild, judge, degree);
		postOrder(tn->rightChild, judge, degree);
		cout << tn->element;	
		judge++;
		if (judge < degree)
			cout << ",";
	} 
}

void levelOrder(treeNode *tn, int &judge, int degree)
{
	arrayQueue q;
	while (tn != NULL)
	{
		cout << tn->element;
		judge++;
		if (judge < degree)
			cout << ","; 
		if (tn->leftChild != NULL)
			q.push(tn->leftChild);
		if (tn->rightChild != NULL)
			q.push(tn->rightChild);
		if (q.empty())
			return;
		else
			tn = q.front();
		q.pop();
	}
}

treeNode* makeTree(string str21, string str22, int degree)
{
	if (degree == 0)
		return NULL;
	int k = 0;
	while (str21[0] != str22[k])
		k++;
	treeNode *t = new treeNode(str21[0]);
	t->leftChild = makeTree(str21.substr(1, degree-1), str22, k);
	t->rightChild = makeTree(str21.substr(k+1, degree-k-1), str22.substr(k+1, degree-k-1), degree-k-1);
	return t;
} 











