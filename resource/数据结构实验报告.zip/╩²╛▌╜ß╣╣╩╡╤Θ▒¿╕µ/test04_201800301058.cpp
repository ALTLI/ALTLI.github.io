#include <iostream>
#include <string>
using namespace std;

int judge(char, char, int[7][7]);
void transfer(string&, int, char*&, int[7][7]);
int calculate(char*&, int);

int main()
{
	cout << "Input" << endl;
	string str;
	cin >> str;
	str.append("#");
	int num = str.size();
	char* arr = new char[num];
	// ÿһ��ÿһ�д����Ҵ��ϵ��£�Ϊ+ - * / ( ) # 
	// һ����>Ϊ1��<Ϊ0��=Ϊ2��������Ϊ3 
	int pri[7][7] = {{1, 1, 0, 0, 0, 1, 1},
		   			 {1, 1, 0, 0, 0, 1, 1},
		   			 {1, 1, 1, 1, 0, 1, 1},
		   			 {1, 1, 1, 1, 0, 1, 1},
		   			 {0, 0, 0, 0, 0, 2, 3},
		   			 {1, 1, 1, 1, 3, 1, 1},
		  			 {0, 0, 0, 0, 0, 3, 2}};
	int all = 0;
	for(int i = 0; i < num; i++)
	{
		if(str[i] != '(' && str[i] != ')')
			all++;
	}
	transfer(str, num, arr, pri);
	cout << endl;
	int result = calculate(arr, --all);
	cout << "Output" << endl;
	cout << result << endl;
	cout << "End" << endl;
	return 0;
}

void transfer(string& str, int num, char*& arr, int pri[7][7])
{
	char* symbol = new char[num];
	symbol[0] = '#';
	int p = 0;
	int tp = 1;
	for (int i = 0; i < num; i++)
	{
		if (str[i] >= 48 && str[i] <= 57)
		{
			arr[p] = str[i];
			p++;				
		}
		else
		{
			int flag = judge(symbol[tp-1], str[i], pri);
			if(flag == 0)
			{	
				symbol[tp] = str[i];
				tp++;
			}		
			else if(flag == 1)
			{	
				while (flag == 1)
				{
					arr[p++] = symbol[--tp];
					flag = judge(symbol[tp-1], str[i], pri);
					if(flag == 0) 
					{
						symbol[tp] = str[i];
						tp++;
					} 
					if(flag == 2)
					{
						if(symbol[tp-1] == '(' && str[i] == ')')
						{
							tp--; 
						}		
					}	
				}
			}
			else if(flag == 2)
			{
				if(symbol[tp-1] == '(' && str[i] == ')')
				{
					tp--;
				}
				else
				{
					if(symbol[tp-1] == '#' && str[i] == '#')
					{
						cout << "true";
						break;
					}
					else
					{
						// �׳��쳣 
					}
				}
			}
		}
	}
	delete [] symbol;
}

int judge(char ch1, char ch2, int pri[7][7])
{
	// ch1�ǵ�ǰջ����Ԫ�أ�ch2�ǵ�ǰɨ���ַ� 
	int p[2] = {0, 0};
	char ch[2] = {ch1, ch2}; 
	for(int i = 0; i < 2; i++)
	{
		switch (ch[i])
		{
			case '+': p[i] = 0; break;
			case '-': p[i] = 1; break;
			case '*': p[i] = 2; break;
			case '/': p[i] = 3; break;
			case '(': p[i] = 4; break;
			case ')': p[i] = 5; break;
			case '#': p[i] = 6; break;
		}
	}
	return pri[p[0]][p[1]];
}

int calculate(char*& arr, int all)
{
	int* temp = new int[all];
	int tp = 0;
	for(int i = 0; i < all; i++)
	{
		if(arr[i] >= 48 && arr[i] <= 57)
		{
			temp[tp] = int(arr[i])-48;
			tp++;
		}	
		else
		{
			if(tp == 1)
				break;
			else
			{
				switch (arr[i])
				{
					case '+': 
						temp[tp-2] = temp[tp-2] + temp[tp-1]; break;
					case '-': 
						temp[tp-2] = temp[tp-2] - temp[tp-1]; break;
					case '*': 
						temp[tp-2] = temp[tp-2] * temp[tp-1]; break;
					case '/': 
						temp[tp-2] = temp[tp-2] / temp[tp-1]; break;
				}
				tp--;
			}
		}
	} 
	int result = temp[0];
	delete [] temp;
	return result;	
}









