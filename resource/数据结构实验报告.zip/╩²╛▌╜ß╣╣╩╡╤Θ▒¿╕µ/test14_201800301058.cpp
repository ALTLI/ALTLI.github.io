#include <iostream>
#include <string>
using namespace std;

struct position
{
	int row;
	int col;
		
}; 

class arrayStack
{
	public:
		position stack[100];
		arrayStack()
		{
			nums = 0;
			stackTop = -1; 
			
		}
		int topNum()
		{
			return stackTop;
		}
		void push(const position& thePosition)
		{
			stack[++stackTop] = thePosition;
		}
		void pop()
		{
			stackTop--;
		}
		position& top()
		{
			return stack[stackTop];
		}
			
	private:
		int stackTop;
		int nums;
};

void findPath(int [10][10]);

int main()
{
	int maze[10][10];
	string inMaze[10];
	cout << "Input" << endl;
	for (int i = 0; i < 10; i++)
	{
		cin >> inMaze[i];
	}
	for (int i = 0; i < 10; i++)
	{
		int k = 0;
		for (int j = 0; j < 10; j++)
		{
			maze[i][j] = inMaze[i][k] - 48;	
			k++;
		}	
	} 
	cout << "Output" << endl;
	findPath(maze);
	cout << "End" << endl;
	return 0;
}

void findPath(int maze[10][10])
{
	arrayStack path;
	// ȷ�������ķ���ʹ�С����0-3�ֱ�Ϊ�ҡ��¡����� 
	position step[4];
	step[0].row = 0; step[0].col = 1;
	step[1].row = 1; step[1].col = 0;
	step[2].row = 0; step[2].col = -1;
	step[3].row = -1; step[3].col = 0; 
	position here;
	here.row = 1;
	here.col = 1;
	maze[1][1] = 1;
	int option = 0;
	int lastOption = 3;
	while (here.row != 8 || here.col != 8)
	{
		int r, c;
		while (option <= lastOption)
		{
			r = here.row + step[option].row;
			c = here.col + step[option].col;
			if (maze[r][c] == 0)
				break;
			option++;
		}
		if (option <= lastOption)
		{
			path.push(here);
			here.row = r;
			here.col = c;
			maze[r][c] = 1;
			option = 0;
		}
		else
		{
			position next = path.top();
			path.pop();
			if (next.row == here.row)
				option = 3;
			else
				option = 2;
			here = next;
		}
	}
	int i = 0;
	for (position p = path.stack[0]; i <= path.topNum(); p = path.stack[++i])
	{
		cout << "(" << p.row << "," << p.col << ")" << endl;
	}
	cout << "(8,8)" << endl;
}












