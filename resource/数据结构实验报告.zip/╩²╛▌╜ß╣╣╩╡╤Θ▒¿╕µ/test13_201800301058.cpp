#include <iostream>
using namespace std;

struct chainNode
{
	int element;
	chainNode* next;

	chainNode() {}
	chainNode(const int& element)
	{
		this->element = element;
		this->next = NULL;
	}
	chainNode(const int& element, chainNode*& next)
	{
		this->element = element;
		this->next = next;
	}
};

void sort(chainNode*&, int);
void deleteNode(chainNode*&, int);

int main()
{
	chainNode* firstNode = NULL;
	chainNode* currentNode = NULL;
	cout << "Input1" << endl;
	int element;
	int addition = 0;
	while (cin >> element)
	{
		if (element != 0)
		{
			addition++;
			chainNode* node = new chainNode(element);
			if (firstNode == NULL)
				firstNode = currentNode = node;
			else
			{
				currentNode->next = node;
				currentNode = node;
			}
		}
		else
		{
			currentNode->next = NULL;
			break;
		}
	}
	cout << "Output1" << endl;
	sort(firstNode, addition);
	cout << "Input2" << endl;
	int num2;
	cin >> num2;
	cout << "Output2" << endl;
	deleteNode(firstNode, num2);
	cout << "Input3" << endl;
	int num3;
	cin >> num3;
	cout << "Output3" << endl;
	deleteNode(firstNode, num3);
	cout << "End" << endl;
	return 0;
}

void sort(chainNode*& firstNode, int addition)
{
	int* arr = new int[addition];
	int i = 0;
	for (; firstNode != NULL; firstNode = firstNode->next)
	{
		arr[i] = firstNode->element;
		i++;
	}
	for (int j = 0; j < i; j++)
		for (int k = 0; k < i - 1; k++)
			if (arr[k] > arr[k + 1])
				swap(arr[k], arr[k + 1]);
	chainNode* p = NULL;
	for(int j = 0; j < addition; j++)
	{
		chainNode* tp = new chainNode(arr[j]);
		if(firstNode == NULL)
			firstNode =  p = tp;
		else
		{
			p->next = tp;
			p = tp;
		}			
	}
	if(firstNode != NULL)
		p->next = NULL;
	for(p = firstNode; p != NULL; p = p->next)
	{
		cout << p->element;
		if(p->next != NULL)
			cout << ",";
	}
	cout << endl;
}

void deleteNode(chainNode*& firstNode, int num2)
{
	if(firstNode->element == num2)
	{
		firstNode = firstNode->next;
	}
	else
	{
		chainNode* p = firstNode->next;
		chainNode* tp = firstNode;
		for(; p != NULL; p = p->next)
		{
			if(p->element == num2)
			{
				tp->next = p->next;
				break;
			}
			tp = p;
		}
	}
	for(chainNode* p = firstNode; p != NULL; p = p->next)
	{
		cout << p->element;
		if(p->next != NULL)
			cout << ",";
	}
	cout << endl;
}










