#include <iostream>
using namespace std;

struct treeNode
{
	int element;
	treeNode *leftChild;
	treeNode *rightChild;
	treeNode()
	{
		leftChild = rightChild = NULL;
	}
	treeNode(int theElement)
	{
		element = theElement;
		leftChild = rightChild = NULL;
	}
	treeNode(int theElement, treeNode *theLeftChild, treeNode *theRightChild)
	{
		element = theElement;
		leftChild = theLeftChild;
		rightChild = theRightChild;
	}
};

class arrayQueue
{
	public:
		treeNode *queue[100];
		arrayQueue()
		{
			queueFront = -1;
			elementSize = 0;
			queueBack = -1;
		}
		void push(treeNode *theTreeNode)
		{
			queueBack = (queueBack+1)%100;
			queue[queueBack] = theTreeNode;
			elementSize++;
		}
		void pop()
		{
			queueFront = (queueFront+1)%100;
			elementSize--;
		}
		treeNode* front()
		{
			return queue[(queueFront+1)%100]; 
		}
		bool empty()
		{
			return elementSize == 0;
		}
		
		
	private:
		int queueFront;
		int elementSize;
		int queueBack;
};

void initialize(int [], int);
void pop(int [], int);
int top(int []);
void heapSort(int [], int, int []);
void makeBSTree(int [], int, treeNode *, int &);
void preOrder(treeNode *, int &, int);
void inOrder(treeNode *, int &, int);

int main()
{
	int inNums[25];
	int heap[25];
	int nums = 0;
	cout << "Input" << endl;
	while (cin >> inNums[nums])
	{
		heap[nums+1] = inNums[nums];
		if (inNums[nums] == 0)
			break;
		nums++;
	}
	cout << "Output" << endl;
	initialize(heap,nums);
	for (int i = 1; i <= nums; i++)
	{
		cout << heap[i];
		if (i < nums)
			cout << ",";
	}
	cout << endl;
	int sort[25];
	heapSort(sort, nums, heap);
	for (int i = 1; i <= nums; i++)
	{
		cout << sort[i];
		if (i < nums)
			cout << ",";
	}
	cout << endl;
	treeNode *BSRoot = new treeNode(inNums[0]);
	int size = 1;
	makeBSTree(inNums, nums, BSRoot, size);
	int judge1 = 0, judge2 = 0;
	preOrder(BSRoot, judge1, size);
	cout << endl;
	inOrder(BSRoot, judge2, size);
	cout << endl;
	cout << "End" << endl;	
	return 0;
}

void initialize(int heap[], int nums)
{
	int heapSize = nums;
	for (int root = heapSize/2; root >= 1; root--)
	{
		int rootElement = heap[root];
		int child  = 2*root;
		while (child <= heapSize)
		{
			if (child < heapSize && heap[child] < heap[child+1])
				child++;
			if (rootElement >= heap[child])
				break;
			heap[child/2] = heap[child];
			child *= 2;
		}
		heap[child/2] = rootElement;
	}
}

void pop(int heap[], int nums)
{
	int heapSize = nums;
	int lastElement = heap[heapSize--];
	int currentNode = 1, child = 2;
	while (child <= heapSize)
	{
		if (child < heapSize && heap[child] < heap[child+1])
			child++;
		if (lastElement >= heap[child])
			break;
		heap[currentNode] = heap[child];
		currentNode = child;
		child *= 2;
	}
	heap[currentNode] = lastElement; 
}

int top(int heap[])
{
	return heap[1];
}

void heapSort(int sort[], int nums, int heap[])
{
	for (int i = nums; i >= 1; i--)
	{
		int x = top(heap);
		pop(heap, i);
		sort[i] = x;
	}
}

void makeBSTree(int inNums[], int nums, treeNode *root, int &size)
{
	for (int i = 1; i < nums; i++)
	{
		bool flag = true;
		treeNode *p = root;
		treeNode *pt = NULL;
		for (int j = 0; j < 10 && p != NULL; j++)
		{
			pt = p;
			if (inNums[i] < p->element)
			{
				p = p->leftChild;	
			}
			else
			{
				if (inNums[i] > p->element)
				{
					p = p->rightChild;
				}				
				else
				{
					// �����ظ���ֵ����������ֵ 
					flag = false; 
				}
			}
		}
		if (flag)
		{
			treeNode *newNode = new treeNode(inNums[i]);
			if (inNums[i] < pt->element)
			{
				pt->leftChild = newNode;			
			}
			else
			{
				pt->rightChild = newNode;	
			}
			size++;
		}		
	}
}

void preOrder(treeNode *tn, int &judge, int degree)
{
	if (tn != NULL)
	{
		
		cout << tn->element;
		judge++;
		if (judge < degree)
			cout << ",";
		preOrder(tn->leftChild, judge, degree);
		preOrder(tn->rightChild, judge, degree);
	}
} 

void inOrder(treeNode *tn, int &judge, int degree)
{
	if (tn != NULL)
	{
		inOrder(tn->leftChild, judge, degree);
		cout << tn->element;
		judge++;
		if (judge < degree)
			cout << ",";
		inOrder(tn->rightChild, judge, degree);
	}
}




