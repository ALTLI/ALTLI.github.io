#include <iostream>
#include <string>
#include <cmath>
using namespace std;

struct treeNode
{
	char element;
	treeNode *leftChild;
	treeNode *rightChild;
	treeNode()
	{
		leftChild = rightChild = NULL;
	}
	treeNode(char theElement)
	{
		element = theElement;
		leftChild = rightChild = NULL;
	}
	treeNode(char theElement, treeNode *theLeftChild, treeNode *theRightChild)
	{
		element = theElement;
		leftChild = theLeftChild;
		rightChild = theRightChild;
	}
};

class arrayQueue
{
	public:
		treeNode *queue[100];
		arrayQueue()
		{
			queueFront = -1;
			elementSize = 0;
			queueBack = -1;
		}
		void push(treeNode *theTreeNode)
		{
			queueBack = (queueBack+1)%100;
			queue[queueBack] = theTreeNode;
			elementSize++;
		}
		void pop()
		{
			queueFront = (queueFront+1)%100;
			elementSize--;
		}
		treeNode* front()
		{
			return queue[(queueFront+1)%100]; 
		}
		bool empty()
		{
			return elementSize == 0;
		}
		
		
	private:
		int queueFront;
		int elementSize;
		int queueBack;
};

void levelOrder(treeNode *, int &, int);
void preOrder(treeNode *, int &, int);
treeNode* makeTree(string, string, int);

int main()
{
	string str1, str2;
	cout << "Input" << endl;
	cin >> str1;
	cin >> str2;
	int degree = str1.size();
	treeNode *root = makeTree(str1, str2, degree);
	cout << "Output" << endl;
	int judge1 = 0, judge2 = 0;
	preOrder(root, judge1, degree);
	cout << endl;
	levelOrder(root, judge2, degree);
	cout << endl;
	cout << "End" << endl;
	return 0;
}

void levelOrder(treeNode *tn, int &judge, int degree)
{
	arrayQueue q;
	while (tn != NULL)
	{
		cout << tn->element;
		judge++;
		if (judge < degree)
			cout << ","; 
		if (tn->leftChild != NULL)
			q.push(tn->leftChild);
		if (tn->rightChild != NULL)
			q.push(tn->rightChild);
		if (q.empty())
			return;
		else
			tn = q.front();
		q.pop();
	}
}

void preOrder(treeNode *tn, int &judge, int degree)
{
	if (tn != NULL)
	{
		
		cout << tn->element;
		judge++;
		if (judge < degree)
			cout << ",";
		preOrder(tn->leftChild, judge, degree);
		preOrder(tn->rightChild, judge, degree);
	}
} 

treeNode* makeTree(string str1, string str2, int degree)
{
	if (degree == 0)
		return NULL;
	int k = 0;
	while (str1[degree-1] != str2[k])
		k++;
	treeNode *t = new treeNode(str1[degree-1]);
	t->leftChild = makeTree(str1.substr(0, degree-1), str2, k);
	t->rightChild = makeTree(str1.substr(k, degree-k-1), str2.substr(k+1, degree-k-1), degree-k-1);
	return t;
} 











