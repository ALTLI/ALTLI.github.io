#include <iostream>
#include <string>
#include <cmath> 
using namespace std;

class arrayQueue
{
	public:
		int queue[100];
		arrayQueue()
		{
			queueFront = -1;
			elementSize = 0;
			queueBack = -1;
		}
		void push(int position)
		{
			queueBack = (queueBack+1)%100;
			queue[queueBack] = position;
			elementSize++;
		}
		void pop()
		{
			queueFront = (queueFront+1)%100;
			elementSize--;
		}
		int front()
		{
			return queue[(queueFront+1)%100]; 
		}
		bool empty()
		{
			return elementSize == 0;
		}
		
		
	private:
		int queueFront;
		int elementSize;
		int queueBack;
};

void BFS(int **&, int, int [], int, int [], int &);
void DFS(int **&, int , int, int [], int, int [], int &);
void findPath(int **&, int, int, int, int [], int, int &, bool &);

int main()
{
	string str;
	int n, m;
	cout << "Input" << endl;
	cin >> str;
	n = (int)str[0]-48;
	int strSize = str.size();
	int x = 0;
	for (int i = strSize-1; i >= 2; i--)
	{
		m += ((int)str[i]-48)*pow(10, x++);
	}
	string *arrStr = new string[m];
	for (int i = 0; i < m; i++)
	{
		cin >> arrStr[i];
	}	
	int **graph = new int* [n+1];
	for (int i = 1; i <= n; i++)
	{
		graph[i] = new int[n+1];
		for (int j = 1; j <= n; j++)
		{
			graph[i][j] = 0;
		}
	}
	for (int i = 0; i < m; i++)
	{
		int length = 5;
		for (int j = 5; arrStr[i][j] != '\0'; j++)
			length++;
		int row = (int)arrStr[i][0]-48;
		int col = (int)arrStr[i][2]-48;
		int value = 0;
		int xx = 0;
		for (int j = length-1; j >= 4; j--)
		{
			value += ((int)arrStr[i][j]-48)*pow(10, xx++);
		}
		graph[row][col] = value;
		graph[col][row] = value;
	}
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n; j++)
//		{
//			cout << graph[i][j];
//		}
//		cout << endl;
//	 } 
	cout << "Output" << endl;
	int reach1[50];
	int reach2[50];
	int arrive1[50];
	int arrive2[50];
	int arrive[50];
	for (int i = 0; i < 50; i++)
	{
		reach1[i] = 0;
		reach2[i] = 0;
		arrive1[i] = 0;
		arrive2[i] = 0;
		arrive[i] = 0;
	}
	int label = 1;
	int count1 = 0;
	BFS(graph, n, reach1, label, arrive1, count1);
	for (int i = 0; i < count1; i++)
	{
		cout << arrive1[i];
		if (i < count1-1)
			cout << ","; 
	}
	cout << endl;
	int count2 = 0;
	DFS(graph, 1, label, reach2, n, arrive2, count2);
	for (int i = 0; i < count2; i++)
	{
		cout << arrive2[i];
		if (i < count2-1)
			cout << ","; 
	}
	cout << endl;
	int path[200];
	for (int i = 0; i < 200; i++)
	{
		path[i] = 0;	
	}
	int min = 10000; 
	int count = 0;
	bool Flag = false;
	findPath(graph, 1, label, n, arrive, count, min, Flag);
	if (Flag)
		cout << min << endl;
	else
		cout << 0 << endl;
	cout << "End" << endl;
	return 0;
}

void BFS(int **&graph, int n, int reach[], int label, int arrive[], int &count)
{
	arrayQueue q;
	reach[1] = label;
	q.push(1);
	cout << 1 << ",";
	while (!q.empty())
	{
		int w = q.front();
		q.pop();
		for (int u = 1; u <= n; u++)
		{
			if (graph[w][u] != 0 && reach[u] == 0)
			{
				q.push(u);
				reach[u] = label;	
				arrive[count++] = u;
			}	
		} 	
	}
}

void DFS(int **&graph, int v, int label, int reach[], int n, int arrive[], int &count)
{
	// �������������������⣬��ֻ�ǵ�����¼��һ�η��ʵĽڵ�
	// �ο���ֵ����
	// ������������������������findPath���������賿2���ڴ����������
	// ���ԣ����ɿ������findPath�����DFS�ɺ��� 
	reach[v] = label;
	arrive[count++] = v;
	int ae[15];
	for (int i = 0; i < 15; i++)
	{
		ae[i] = 0;
	}
	int x = 0;
	for (int j = v; j <= n; j++)
	{
		if (graph[v][j] != 0)
		{
			ae[x++] = j; 
		}
	}
	int y = 0;
	for (int w = ae[y]; y < x; y++)
		if (!reach[w])
		{
			DFS(graph, w, label, reach, n, arrive, count);
		}
}

void findPath(int **&graph, int v, int label, int n, int arrive[], int count, int &min, bool &Flag)
{
	arrive[count++] = v;
//	cout << count << endl;
//	for (int i = 0; i < count; i++)
//		cout << arrive[i] << " ";
//	cout << endl;
	if (v == n)
	{
		Flag = true;
		int result = 0;
		for (int i = 0; i < count-1; i++)
		{
			result += graph[arrive[i]][arrive[i+1]];	
//		cout << arrive[i];
		}
//		cout << result << endl;
		if (result < min)
		{
			min = result;
		}
	}
	int adj[15];
	for (int i = 0; i < 15; i++)
	{
		adj[i] = 0;
	}
	int x = 0;
	for (int j = v; j <= n; j++)
	{
		if (graph[v][j] != 0)
		{
			adj[x++] = j; 
		}
	}
	int flag[15];
	for (int i = 0; i < 15; i++)
	{
		flag[i] = 0;
	}
	int y = 0;
	for (int w = adj[y]; y < x; w = adj[++y])
	{
		if (!flag[y])
		{
			flag[y] = label;
			findPath(graph, w, label, n, arrive, count, min, Flag);
		}
	}		
}

















