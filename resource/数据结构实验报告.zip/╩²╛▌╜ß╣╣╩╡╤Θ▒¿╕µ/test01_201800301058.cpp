#include <iostream>
#include <iterator>
using namespace std;

void permutations(int[], int, int, int[], int);

int main()
{
	int arr[25];
	cout << "Input" << endl;
	int inNums[25];
	int i = 0;
	while (cin >> inNums[i])
	{
		if (inNums[i] == 0)
			break;
		i++;
	}
	cout << "Output" << endl;
	permutations(inNums, 0, i-1, arr, i);
	cout << "End" << endl;
	return 0;
}

void permutations(int inNums[], int k, int m, int arr[], int i)
{
	if (k == m)
	{
		copy(inNums, inNums+m+ 1, arr);
		for (int j = 0; j < i; j++)
		{
			cout << arr[j];
			if (j < i-1)
				cout << ",";
		}
		cout << endl;
	}
	else
	{
		for (int p = k; p <= m; p++)
		{
			swap(inNums[k], inNums[p]);
			permutations(inNums, k+1, m, arr, i);
			swap(inNums[k], inNums[p]);
		}
	}
}
