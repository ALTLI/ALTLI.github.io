#include <iostream>
using namespace std;

void mergeSort(int a[], int n);
void mergePass(int x[], int y[], int n, int segmentSize);
void merge(int c[], int d[], int startOfFirst, int endOfFirst, int endOfSecond);

int main()
{
	cout << "Input" << endl;
	int inNums[25];
	int i = 0;
	while(cin >> inNums[i])
	{
		if(inNums[i] == 0)
			break;
		i++;
	}
	cout << "Output" << endl;
	cout << "�鲢����" << endl;
	mergeSort(inNums, i);
	for(int j = 0; j < i; j++)
	{
		cout << inNums[j];
		if(j < i-1)
			cout << ",";
	}
	cout << endl;
	cout << "End" << endl;
	return 0;
}

void mergeSort(int a[], int n)
{
	int *b = new int[n];
	int segmentSize = 1;
	while(segmentSize < n)
	{
		mergePass(a, b, n, segmentSize);
		segmentSize += segmentSize;
		mergePass(b, a, n, segmentSize);
		segmentSize += segmentSize;
	}
	delete [] b;
}

void mergePass(int x[], int y[], int n, int segmentSize)
{
	int i = 0;
	while(i <= n-2*segmentSize)
	{
		merge(x, y, i, i+segmentSize-1, i+2*segmentSize-1);
		i = i + 2*segmentSize;
	}
	if(i + segmentSize < n)
	{
		merge(x, y, i, i+segmentSize-1, n-1);
	}
	else
	{
		for(int j = i; j < n; j++)
			y[j] = x[j];
	}
}

void merge(int c[], int d[], int startOfFirst, int endOfFirst, int endOfSecond)
{
	int first = startOfFirst, second = endOfFirst+1, result = startOfFirst;
	while((first <= endOfFirst) && (second <= endOfSecond))
	{
		if(c[first] <= c[second])
			d[result++] = c[first++];
		else
			d[result++] = c[second++];	
	}	
	if(first >endOfFirst)
		for(int q = second; q <= endOfSecond; q++)
			d[result++] = c[q];
	else 
		for(int q = first; q <= endOfFirst; q++)
			d[result++] = c[q];
}
















