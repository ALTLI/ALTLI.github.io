#include <iostream>
using namespace std;



struct chainNode
{
	int element;
	chainNode* next;
	
	chainNode(){}
	chainNode(int element)
	{
		this->element = element;
		this->next = NULL;
	}
};
void subset(int[], int[], int, int);
int main()
{
	int arr[25];
	cout << "Input" << endl;
	int inNums[25];
	int nums = 0;
	while (cin >> inNums[nums])
	{
		if (inNums[nums] == 0)
			break;
		nums++;
	}
	cout << "Output" << endl;
	subset(inNums, arr, 0, nums);
	cout << "End" << endl;
	return 0;
}
void subset(int inNums[], int arr[], int i, int n)
{
	if (i == n)
	{
		cout << "{";
		chainNode* firstNode = NULL;
		chainNode* p = NULL;
		for (int j = 0; j < n; j++)
		{
			if (arr[j] == 1)
			{
				chainNode* tp = new chainNode(inNums[j]);
				if(firstNode == NULL)
					firstNode = p = tp;
				else
				{
					p->next = tp;
					p = tp;  
				}
			}
		}
		p = firstNode;
		for(; p != NULL; p = p->next)
		{
			cout << p->element;
			if(p->next != NULL)
				cout << ",";
		}
		cout << "}" << endl;
		return;
	}
	arr[i] = 0;
	subset(inNums, arr, i + 1, n);
	arr[i] = 1;
	subset(inNums, arr, i + 1, n);
}
