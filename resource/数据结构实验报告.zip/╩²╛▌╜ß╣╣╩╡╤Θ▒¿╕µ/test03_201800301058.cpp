#include <iostream>
using namespace std;

struct chainNode
{
	int element;
	chainNode* next;

	chainNode() {}
	chainNode(const int& element)
	{
		this->element = element;
	}
	chainNode(const int& element, chainNode*& next)
	{
		this->element = element;
		this->next = next;
	}
};

void sort(chainNode*&, int);
void insert(chainNode*&, int);
int find(chainNode*&, int);
void unionChainNode(chainNode*&, chainNode*&);

int main()
{
	chainNode* firstNode = NULL;
	chainNode* currentNode = NULL;
	cout << "Input1" << endl;
	int element;
	int addition = 0;
	while (cin >> element)
	{
		if (element != 0)
		{
			addition++;
			chainNode* node = new chainNode(element);
			if (firstNode == NULL)
				firstNode = currentNode = node;
			else
			{
				currentNode->next = node;
				currentNode = node;
			}
		}
		else
		{
			currentNode->next = NULL;
			break;
		}
	}
	cout << "Output1" << endl;
	sort(firstNode, addition);
	cout << "Input2" << endl;
	int num2;
	cin >> num2;
	cout << "Output2" << endl;
	insert(firstNode, num2);
	cout << "Input3" << endl;
	int num3;
	cin >> num3;
	cout << "Output3" << endl;
	int result = find(firstNode, num3);
	if(result == 0)
		cout << 0 << endl;
	else
		cout << result << endl;
	cout << "Input4" << endl;
	int num4;
	cin >> num4;
	cout << "Output4" << endl;
	result = find(firstNode, num4);
	if(result == 0)
		cout << 0 << endl;
	else
		cout << result << endl;
	cout << "Input5" << endl;
	chainNode* secondNode = NULL;
	currentNode = NULL;
	int addition1 = 0;
	while (cin >> element)
	{
		if (element != 0)
		{
			addition1++;
			chainNode* node = new chainNode(element);
			if (secondNode == NULL)
				secondNode = currentNode = node;
			else
			{
				currentNode->next = node;
				currentNode = node;
			}
		}
		else
		{
			currentNode->next = NULL;
			break;
		}
	}
	cout << "Output5" << endl;
	sort(secondNode, addition1);
	unionChainNode(firstNode, secondNode);
	cout << "End" << endl;
	return 0;
}

void sort(chainNode*& firstNode, int addition)
{
	int* arr = new int[addition];
	int i = 0;
	for (; firstNode != NULL; firstNode = firstNode->next)
	{
		arr[i] = firstNode->element;
		i++;
	}
	for (int j = 0; j < i; j++)
		for (int k = 0; k < i - 1; k++)
			if (arr[k] > arr[k + 1])
				swap(arr[k], arr[k + 1]);
	chainNode* p = NULL;
	for(int j = 0; j < addition; j++)
	{
		chainNode* tp = new chainNode(arr[j]);
		if(firstNode == NULL)
			firstNode =  p = tp;
		else
		{
			p->next = tp;
			p = tp;
		}			
	}
	if(firstNode != NULL)
		p->next = NULL;
	for(p = firstNode; p != NULL; p = p->next)
	{
		cout << p->element;
		if(p->next != NULL)
			cout << ",";
	}
	cout << endl;
}

void insert(chainNode*& firstNode, int num2)
{
	chainNode* p = NULL;
	if(firstNode == NULL)
	{
		firstNode = new chainNode(num2);
	}
	bool flag = false;
	for (chainNode* currentNode = firstNode; currentNode != NULL; currentNode = currentNode->next)
	{
		if(firstNode->element > num2)
		{
			flag = true;
			firstNode = new chainNode(num2, firstNode);
			break;
		}
		if(currentNode->element == num2)
		{
			flag = true;
			chainNode* temp = new chainNode(num2);
			temp->next = currentNode->next;
			currentNode->next = temp;
			break;
		}
		else if(currentNode->element < num2)
		{
			p = currentNode;
			continue;
		}
		else
		{
			chainNode* tp = new chainNode(num2);
			p->next = tp;
			tp->next = currentNode;
			flag = true;
			break;
		}
	}
	if(!flag)
	{
		chainNode* tpp = new chainNode(num2);
		p->next = tpp;
		tpp->next = NULL;
	}
	for(p = firstNode; p != NULL; p = p->next)
	{
		cout << p->element;
		if(p->next != NULL)
			cout << ",";
	}
	cout << endl;	
}

int find(chainNode*& firstNode, int num3)
{
	chainNode* p = firstNode;
	int addition = 0;
	for (; p != NULL; p = p->next)
	{
		addition++;
		if(p->element == num3)
		{
			return addition;
		}
	}
	return 0;
}

void unionChainNode(chainNode*& firstNode, chainNode*& secondNode)
{
	chainNode* outNode = NULL;
	chainNode* p = NULL;
	chainNode *p1 = firstNode;
	chainNode *p2 = secondNode;
	for(; p1 != NULL && p2 != NULL;)
	{
		if(p1->element <= p2->element)
		{
			if(outNode == NULL)
			{
				outNode = p = p1;
			}
			else
			{
				p->next = p1;
				p = p1;
			}
			p1 = p1->next; 
		}
		else
		{
			if(outNode == NULL)
			{
				outNode = p = p2;
			}
			else
			{
				p->next = p2;
				p = p2;
			}
			p2 = p2->next; 
		}
	}
	if(p1 != NULL || p2 != NULL)
	{
		if(p1 != NULL)
			p->next = p1;
		else
			p->next = p2;
	}
	for(; outNode != NULL; outNode = outNode->next)
	{
		cout << outNode->element;
		if(outNode->next != NULL)
			cout << ",";
	}
	cout << endl;
}
















